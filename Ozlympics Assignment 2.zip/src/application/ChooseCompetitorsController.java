/**
 * ChooseCompetitorsController is the controller 
 *	class for the ChooseCompetitors.fxml file.
 * Action events include: backToMenu(), submitCompetitors() 
 * and selection of a toggle button.
 * Supporting methods are initialize(),setCompetitor() and checkToggles()
 */

package application;

import java.io.IOException;
import java.util.*;
import application.model.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.text.*;
import javafx.stage.Stage;

public class ChooseCompetitorsController  {

    private SetUpGame setUpGame;
    private ArrayList<ToggleButton> toggleButton  = new ArrayList<ToggleButton>();

    @FXML
    private GridPane competitorsTable;

    @FXML
    private Button submitCompetitors;

    @FXML
    private Button backToMenu;
    
    /**
     *  Called by the SetUpGame Class to give access back to itself
     *  
     *  @param setUpGame
     */
    public void setSetUpGame (SetUpGame setUpGame) {
    	this.setUpGame=setUpGame;
    }

    
    /**
     *Initializes the ChooseCompetitors.fxml file with Athlete info
     *after it has been loaded.
     */
    @FXML
    public void initialize() {
    	//Create new toggle buttons and labels for each athlete
    	for (int i = 0; i < Athlete.getAllAthletes().size(); i++){
    		ToggleButton j = new ToggleButton(Athlete.getAllAthletes().
    										  get(i).getId());
    		Label k= new Label(Athlete.getAllAthletes().get(i).getName());
    		Label l= new Label(Athlete.getAllAthletes().get(i).getType());
	   
    		//Add the toggle button and labels the grid pane:competitors table 
    		toggleButton.add(j);
    		competitorsTable.add(j, 0, i+1);
    		competitorsTable.add(k,1,i+1);
    		competitorsTable.add(l, 2, i+1);
	   
    		//Set the style for the toggle buttons and labels
    		j.setFont(Font.font("American Typewriter", 12)); 
    		j.setTextFill(Color.WHITE);
    		k.setFont(Font.font("American Typewriter", 
    				FontWeight.EXTRA_LIGHT, 13)); 
    		k.setTextFill(Color.WHITE);
    		l.setFont(Font.font("American Typewriter", 
    				FontWeight.EXTRA_LIGHT, 13)); 
    		l.setTextFill(Color.WHITE);
    		j.setStyle("-fx-background-color: #ffa500");
	    
    		//Set action event for selection of toggle buttons: 
    		//Color text to black.
    		j.setOnAction(e -> {
    			for (int m=0; m<toggleButton.size(); m++){
    				if(toggleButton.get(m).isSelected()){
    					toggleButton.get(m).setTextFill(Color.BLACK);
    				} else toggleButton.get(m).setTextFill(Color.WHITE);
    			}
    		});
    	}    
    }
    
    
    /**
     *  Sends user back to the initial Menu
     *  
     * @param event
     * @exception FileErrorException
     * @exception IOException
     */
    @FXML
    void backToMenu(ActionEvent event) throws FileErrorException, IOException {
    	try {
    		System.out.println("Going back to the menu...");
    		Stage stage = (Stage) backToMenu.getScene().getWindow();
    		stage.close();
    		Parent menuPane = (AnchorPane) FXMLLoader.load(Ozlympic.class.
    				getResource("/application/view/Menu.fxml"));
    		Stage menu = new Stage();
    		menu.setScene(new Scene(menuPane));
    		menu.show();
    	} catch (IOException e) {
    		e.printStackTrace();
    		throw new FileErrorException(
    				"/application/view/ErrorMessageTemplate.fxml");
    	}
    		
    }

    
    /**
     * Checks user choice validity and submits selected competitors for the game
     * 
     * @param event
     * @exception IOException
     * @exception WrongTypeException
     * @exception GameFullException
     * @exception TooFewAthletesException
     * @exception FileErrorException
     * @exception Exception
     */
    @FXML
    void submitCompetitors(ActionEvent event) throws IOException,WrongTypeException,
    GameFullException, TooFewAthletesException, FileErrorException {
    	Stage stage = (Stage) submitCompetitors.getScene().getWindow();
    	stage.close();
    	
    	// Adds selected competitors to the competitors ArrayList.
    	checkToggles();	
    
    	//Checks validity of user competitor selection.
    	checkSelectionValidity();

    	//If selection is valid prints competitors to the console
		System.out.println("Competitors are :");
    	for(Athlete c : setUpGame.getCompetitors()) {
		    System.out.println(c.getId()+" "+c.getName());
		}
		
		//If selection is valid, load ChooseReferee.fxml file
		try {
		    setUpGame.chooseReferee("/application/view/ChooseReferee.fxml");
		} catch (Exception e) {
		    e.printStackTrace();
			throw new FileErrorException(
					"/application/view/ErrorMessageTemplate.fxml");
		}

	}  
    

    /**
     * Checks to see which toggle buttons have been selected.
     * If selected, athlete is added as a competitor.
     */
    public void checkToggles() {
    	for(ToggleButton b: toggleButton) {
    		for (int i=0; i < Athlete.getAllAthletes().size(); i++) {
    			if(b.getText().equals(Athlete.getAllAthletes().get(i).
    					getId())&&((b.isSelected()==true))) {
    				setCompetitor(Athlete.getAllAthletes().get(i));
    			}
    		}
    	}  
    }
    
    /**
     * Sets the competitor for the game, based on user selection
     * 
     * @param choice
     */
    public void setCompetitor(Athlete choice) {	
		switch (setUpGame.getEventType()) {
		case "Swimming": 
		    setUpGame.getCompetitors().add(new Swimmer(choice.getId(), 
		    		choice.getName(),choice.getAge(),choice.getState(),
		    		choice.getType(),choice.getTotalPoints()));   
		    break; 
		case "Cycling":
		    setUpGame.getCompetitors().add(new Cyclist(choice.getId(), 
		    		choice.getName(),choice.getAge(),choice.getState(),
		    		choice.getType(),choice.getTotalPoints()));
		    break;
	            
		case "Running":	
		    setUpGame.getCompetitors().add(new Sprinter(choice.getId(), 
		    		choice.getName(),choice.getAge(),choice.getState(),
		    		choice.getType(),choice.getTotalPoints()));
		    break;
		}
	 }
    
    
    /**
     * Checks the validity of the user competitor selection
     */
    public void checkSelectionValidity() throws  WrongTypeException, 
    GameFullException, TooFewAthletesException, IOException {
    	System.out.println("Checking athlete selection...");
    	for(Athlete c: setUpGame.getCompetitors()) {	
    		//If too many athletes, user is sent back to re-select.
    		if (setUpGame.getCompetitors().size()>8) {
    			setUpGame.getCompetitors().clear();
    			try {
    				setUpGame.showCompetitors(
    						"/application/view/ChooseCompetitors.fxml");
    			} catch (Exception e) {
    				e.printStackTrace();
    			}
    			throw new GameFullException(
    					"/application/view/ErrorMessageTemplate.fxml");	        
    		
    			//If any wrong type of athletes are selected, 
    			//user is sent back to re-select.
    		} else if (!((c.getType().equals(setUpGame.getValidAthlete())||
    				(c.getType().equals("Super"))))) {
    			System.out.println(c.getType());
    			System.out.println(setUpGame.getValidAthlete());
    			setUpGame.getCompetitors().clear();
    			try {
    				setUpGame.showCompetitors(
    						"/application/view/ChooseCompetitors.fxml");
    			} catch (Exception e) {
    				e.printStackTrace();
    			}
    			throw new WrongTypeException(
    					"/application/view/ErrorMessageTemplate.fxml");	        
    		
    			//If not enough athletes are selected,
    			//user is sent back to re-select
    		} else if (setUpGame.getCompetitors().size()<4) {
    			setUpGame.getCompetitors().clear();
    			try {
    				setUpGame.showCompetitors(
    						"/application/view/ChooseCompetitors.fxml");
    			} catch (Exception e) {
    				e.printStackTrace();
    			}
    			throw new TooFewAthletesException(
    					"/application/view/ErrorMessageTemplate.fxml");	        
    		}
    	}	
    }
    
}
