/**
 * ChooseRefereeController Class is the controller class for ChooseReferee.fxml file.
 * Action Events include: backToMenu(), and selection of a referee.
 * Supporting methods are initialize() and setSetUpGame().
 */


package application;

import java.io.IOException;
import java.net.URL;
import java.util.*;
import application.model.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.text.*;
import javafx.stage.Stage;

public class ChooseRefereeController implements Initializable{
	
	private SetUpGame setUpGame;

    @FXML
    private VBox refFrame;
    
    @FXML
    private Button backToMenu;
    
    /**
     *  Called by the SetUpGame Class to give access back to itself
     *  
     *  @param
     */
    public void setSetUpGame (SetUpGame setUpGame) {
    	this.setUpGame = setUpGame;
    }
    
    
    /**
     * Initializes the ChooseReferee.fxml file with Officials info
     * 
     * @param location
     * @param resources
     */  
    @Override
    public void initialize(URL location, ResourceBundle resources) {
    	RadioButton j;
    	ArrayList<RadioButton> radioButton  = new ArrayList<RadioButton>();	
    	// create a new Radio Button for each Official and set the text style.
    	for (int i = 0; i < Official.getAllOfficials().size(); i++){
    		j = new RadioButton(Official.getAllOfficials().get(i).getName());
    		radioButton.add(j);
    		refFrame.getChildren().add(j);
    		j.setFont(Font.font("American Typewriter", FontWeight.LIGHT, 14));
    		j.setTextFill(Color.WHITE);
    	}
    	//Set action event for selection of radio button:
    	//Send user back to the Menu, as Setup is completed.
    	for(RadioButton b: radioButton) {
    		for (Official o : Official.getAllOfficials()) {
    			if(b.getText().equals(o.getName())) {
    				b.setOnAction(e -> {
    					setUpGame.setReferee(o);
    					System.out.println("Selected referee is "+o.getName());
    					Stage stage = (Stage) refFrame.getScene().getWindow();
    					stage.close();
    					try {
    						Parent menuPane = (AnchorPane) FXMLLoader.
    								load(Ozlympic.class.getResource(
    										"/application/view/Menu.fxml"));
    						Stage menu = new Stage();
    						menu.setScene(new Scene(menuPane));
    						menu.show();
    					} catch (IOException e1) {
    						e1.printStackTrace();
    					}
    				});
    			}
    		}
    	}
    }
    
    
    /**
     *  Sends user back to the initial Menu
     *
     * @param event
     * @exception FileErrorException
     * @exception IOException
     */
    @FXML
    void backToMenu(ActionEvent event) throws FileErrorException, IOException {
    	try {
    		System.out.println("Going back to menu...");
    		Stage stage = (Stage) backToMenu.getScene().getWindow();
    		stage.close();
    		Parent menuPane = (AnchorPane) FXMLLoader.load(Ozlympic.
    				class.getResource("/application/view/Menu.fxml"));
    		Stage menu = new Stage();
    		menu.setScene(new Scene(menuPane));
    		menu.show();
    	} catch (IOException e) {
    		e.printStackTrace();
    		throw new FileErrorException(
    				"/application/view/ErrorMessageTemplate.fxml");
    	}
    		
    }
    
    
   



	    
    
	
    

}
