/**
 * DBConnection connects to the SQLite Database OzlympicDb
 */

package application;

import java.sql.*;

public class DbConnection {
    
    private static Connection conn;
    
    public static Connection Connector(String connectionName) {
    	try {
    		Class.forName(connectionName);
    		conn = DriverManager.getConnection("jdbc:sqlite:src/application/model/OzlympicDb.sqlite");
    		return conn;
    	} catch (Exception e) {
    		System.out.println(e);
    		e.printStackTrace();
    		System.out.println("no connection");
    		return null;
    	}
    }

}
