/**
 * DisplayAllGameResultsController is the controller
 *  class for DisplayAllGameResults.fxml file.
 *  Action events include: backToMenu()
 *  Supporting methods are: setOfficial(),loadMenu(),initialize(),
 *  instantiateCompetitorLabels(),showGameDetails(), showCompetitorDetails()
 *  and checkForGames(). 
 */

package application;

import java.io.IOException;
import java.net.URL;
import java.util.*;
import application.model.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.text.*;
import javafx.stage.Stage;

public class DisplayAllGameResultsController implements Initializable {

    private Official official;
    private Game game;
    private ArrayList<Label> ids= new ArrayList<Label>();
    private ArrayList<Label> names= new ArrayList<Label>();
    private ArrayList<Label> results= new ArrayList<Label>();
    private ArrayList<Label> gamePoints= new ArrayList<Label>();
    
    @FXML
    private VBox listOfGames;

    @FXML
    private Button backToMenu;

    @FXML
    private Label referee;

    @FXML
    private Label timestamp;

    @FXML
    private Label numOfCompetitors;

    @FXML
    private GridPane competitorsTable;
    

    /**
     *  Called by the Official Class to give access back to itself
     *  
     *  @param official
     */
    public void setOfficial(Official official) {
	this.official = official;
    }

    
    /**
     * Sends user back to the initial Menu
     *
     * @param event
     * @throws FileErrorException
     * @throws IOException
     */
    @FXML
    void backToMenu(ActionEvent event) throws FileErrorException, IOException {
    	loadMenu();
    }
    
    
    /**
     * Loads the Menu.fxml file.
     *
     * @throws FileErrorException
     * @throws IOException
     */
    public void loadMenu() throws FileErrorException, IOException {
    	try {
    		System.out.println("Going back to the menu...");
    		Stage stage = (Stage) backToMenu.getScene().getWindow();
    		stage.close();
    		Parent menuPane = (AnchorPane) FXMLLoader.load(Ozlympic.class.
    				getResource("/application/view/Menu.fxml"));
    		Stage menu = new Stage();
    		menu.setScene(new Scene(menuPane));
    		menu.show();
    	} catch (IOException e) {
    		e.printStackTrace();
    		throw new FileErrorException(
    				"/application/view/ErrorMessageTemplate.fxml");
    	}
    }


    /**
     * Initializes the DisplayAllGameResults.fxml file with Game Results info
     * after it is loaded.
     * 
     * @param location
     * @param resources
     */  
    @Override
    public void initialize(URL location, ResourceBundle resources) {
    	RadioButton j;
    	ArrayList<RadioButton> radioButton  = new ArrayList<RadioButton>();
    	//ignore the game if there are no competitors for the game.
    	for (int i = 0; i < Game.getAllGames().size(); i++) {
    		if(Game.getAllGames().get(i).getSetUp().getCompetitors().size()==0) {
    			continue;
    			// ignore the game if competitors haven't competed yet.
    		} else if(Game.getAllGames().get(i).getSetUp().getCompetitors().get(1).
	    		getResult()==0) {
    			continue;
    			//assign eventID to the radioButtons, set text style and add the buttons
    			// to the listOfGames pane.
    		} else {
    			j = new RadioButton(Game.getAllGames().get(i).getSetUp().getEventID());
    			radioButton.add(j);
    			listOfGames.getChildren().add(j);
    			j.setFont(Font.font("American Typewriter", FontWeight.LIGHT, 14));
    			j.setTextFill(Color.WHITE);
    		}
    	}
    	//set action for when radio button is selected: Call the
    	// showGameDetails() and the showCompetitorDetails() methods.
    	for(RadioButton b: radioButton) {
    		for (Game g : Game.getAllGames()){
    			if(b.getText().equals(g.getSetUp().getEventID())){
    				b.setOnAction(e -> {
    					System.out.println("Getting game and competitor details...");
    					game=g;
    					showGameDetails(game);
    					showCompetitorsDetails(game);
    				});
    			}
    		}      
    	}
		  instantiateCompetitorLabels();
    }
    
    
    /**
     * Instantiates labels for the competitor details Grid Pane.
     */
    public void instantiateCompetitorLabels() {
	    for (int i = 0; i < 8; i++){
			Label j = new Label();
			ids.add(j);
			Label k = new Label();
			names.add(k);
			Label l = new Label();
			results.add(l);
			Label m = new Label();
			gamePoints.add(m);
			j.setFont(Font.font("American Typewriter", FontWeight.LIGHT, 14));
			j.setTextFill(Color.WHITE);
			k.setFont(Font.font("American Typewriter", FontWeight.LIGHT, 14));
			k.setTextFill(Color.WHITE);
			l.setFont(Font.font("American Typewriter", FontWeight.LIGHT, 14));
			l.setTextFill(Color.WHITE);
			m.setFont(Font.font("American Typewriter", FontWeight.LIGHT, 14));
			m.setTextFill(Color.WHITE);
			competitorsTable.add(j, 0, i+1);
			competitorsTable.add(k,1,i+1);
			competitorsTable.add(l, 2, i+1);
			competitorsTable.add(m, 3, i+1);
		}
    }

    /**
     * Populates the GameDetails section of the DisplayAllGameResults.fxml file
     * with Timestamp, Referee and Number of Competitors for the selected game.
     * 
     * @param game
     */
    public void showGameDetails(Game game) {
    	if (game != null) {
    		timestamp.setText(game.getPlay().getTimestamp());
    		referee.setText(game.getSetUp().getReferee().getName());
  	        numOfCompetitors.setText(Integer.toString(game.getSetUp().getCompetitors().size()));
  	        } else {
  	        	timestamp.setText("");
  	            referee.setText("");
  	            numOfCompetitors.setText("");
  	        }
  	    }
      
    /**
     * Populates CompetitorDetails section of the DisplayAllGameResults.fxml file
     * with IDs, Names, Results, and Game Points of competitors in the selected game.
     * 
     * @param game
     */
    public void showCompetitorsDetails(Game game) {
    	//clear previous details
    	for (int i = 0; i < game.getSetUp().getCompetitors().size(); i++) {
	  	     ids.get(i).setText("");
	  	     names.get(i).setText("");
	  	     results.get(i).setText("");
	  	     gamePoints.get(i).setText("");
	  	     }
    	//set new details
    	for (int i = 0; i < game.getSetUp().getCompetitors().size(); i++) {
    		ids.get(i).setText(game.getSetUp().getCompetitors().get(i).getId());
    		names.get(i).setText(game.getSetUp().getCompetitors().get(i).getName());
    		results.get(i).setText(Integer.toString(game.getSetUp().getCompetitors().
    				get(i).getResult())+" seconds");
    		gamePoints.get(i).setText(Integer.toString(game.getSetUp().
    				getCompetitors().get(i).getGamePoints()));
    		}
     }
      
      /**
       * Called by the Official class when loading the 
       * DisplayAllGameResultsController.fxml file to check if there are, in fact
       * any results to display. If there are no games, displays error message and
       * sends user back to initial menu.
       * 
       * @param fileName
       * @throws FileErrorException 
       * @throws IOException
       */
      public void checkForGames(String fileName) 
    		  throws FileErrorException, IOException {
    	  System.out.println("Checking for valid games...");
    	  if (listOfGames.getChildren().isEmpty()) {
    		  listOfGames.getScene().getWindow().hide();
    		  try {
    			  loadMenu();
    			  FXMLLoader loader = new FXMLLoader();
    			  loader.setLocation(SetUpGame.class.getResource(fileName));
    			  AnchorPane errorMessage = (AnchorPane) loader.load();
    			  Stage error = new Stage();
    			  error.setScene(new Scene(errorMessage));
    			  error.setTitle("Error Occured");
    			  ErrorMessageTemplateController controller = loader.getController();
    			  controller.setGameResultsController(this); 
    			  controller.setMessage("Sorry there are no results to display yet. "
    			  		+ "Please go back to the menu and play a game");
    			  error.show();
    		  } catch (IOException e) {
    			  e.printStackTrace();
    		  }
    	  }
      }
 		
      
}
