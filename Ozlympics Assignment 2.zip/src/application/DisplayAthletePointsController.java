/**
 * DisplayAthletePointsController is the controller class for the 
 * DisplayAthletePoints.fxml file.
 * Action events include: backToMenu().
 * Supporting methods include setOfficial(), getAthletePointsTable()
 * and initialize(). 
 */

package application;

import java.io.IOException;
import java.net.URL;
import java.util.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
import application.model.*;


public class DisplayAthletePointsController implements Initializable { 
    
    public DisplayAthletePointsController() {
    }

    private Official official;
    
    @FXML
    private Button backToMenu;
   
    @FXML
    private GridPane athletePointsTable;

    
    /**
     * Is called by the Official class to set the pointsTable in the centre of
     * the BorderPane
     * 
     * @return athletePointsTable
     */
    @FXML
    public GridPane getAthletePointsTable() {
    	return athletePointsTable;
    }

    
    /**
     *  Called by the Official Class to give access back to itself
     *  
     *  @param official
     */
    public void setOfficial(Official official) {
        this.official = official;    
    }

   
    /**
     * Initialises the DisplayAthletePoints.fxml file with Athlete data when
     * the file is loaded.
     * 
     * @param location
     * @param resources
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
    	//Create new labels, add Athlete data to labels
    	for (int i = 0; i < Athlete.getAllAthletes().size(); i++) {
    		Label j = new Label(Athlete.getAllAthletes().get(i).getId());
    		Label k= new Label(Athlete.getAllAthletes().get(i).getName());
    		Label l = new Label(Athlete.getAllAthletes().get(i).getType());
    		Label m= new Label(Integer.toString(Athlete.getAllAthletes().
    				get(i).getTotalPoints()));
    		//set style of the text in the labels
    		j.setFont(Font.font("American Typewriter", FontWeight.EXTRA_LIGHT, 13)); 
    		j.setTextFill(Color.WHITE);
    		k.setFont(Font.font("American Typewriter", FontWeight.EXTRA_LIGHT, 13)); 
    		k.setTextFill(Color.WHITE);
    		l.setFont(Font.font("American Typewriter", FontWeight.EXTRA_LIGHT, 13)); 
    		l.setTextFill(Color.WHITE);
    		m.setFont(Font.font("American Typewriter", FontWeight.EXTRA_LIGHT, 13)); 
    		m.setTextFill(Color.WHITE);
    		//add labels to the athletePointsTable Grid Pane.
    		athletePointsTable.add(j, 0, i+1);
    		athletePointsTable.add(k,1,i+1);
    		athletePointsTable.add(l, 2, i+1);
    		athletePointsTable.add(m, 3, i+1);
    	}    
    }

    
    /**
     * Sends user back to the initial menu. 
     * 
     * @param event
     * @throws IOException
     * @throws FileErrorException
     */
    @FXML
    void backToMenu(ActionEvent event) throws FileErrorException, IOException {
    	try {
    		System.out.println("Going back to menu...");
    		Stage stage = (Stage) backToMenu.getScene().getWindow();
    		stage.close();
    		Parent menuPane = (AnchorPane) FXMLLoader.load(Ozlympic.class.
    				getResource("/application/view/Menu.fxml"));
    		Stage menu = new Stage();
    		menu.setScene(new Scene(menuPane));
    		menu.show();
    	} catch (IOException e) {
    		e.printStackTrace();
    		throw new FileErrorException(
    				"/application/view/ErrorMessageTemplate.fxml");
    	}		
    }
    
}
