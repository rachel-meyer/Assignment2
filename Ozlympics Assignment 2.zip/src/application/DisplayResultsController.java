/**
 * DisplayResultsController is the controller class for the DisplayResults.fxml file
 * Action events include: backToMenu()
 * Supporting methods includeL initialize()
 */

package application;

import java.io.IOException;

import application.model.FileErrorException;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;

public class DisplayResultsController {

    private PlayGame playGame;

    @FXML
    private GridPane resultTable;

    @FXML
    private Label resultHeading;
     
    @FXML
    private Button backToMenu;

   
    /** Sends user back to the initial menu. 
    * 
    * @param event
    * @throws IOException
    * @throws FileErrorException
    */
   @FXML
   void backToMenu(ActionEvent event) throws FileErrorException, IOException {
   		try {
   			System.out.println("Going back to menu...");
   			Stage stage = (Stage) backToMenu.getScene().getWindow();
   			stage.close();
   			Parent menuPane = (AnchorPane) FXMLLoader.load(Ozlympic.class.
   					getResource("/application/view/Menu.fxml"));
   			Stage menu = new Stage();
   			menu.setScene(new Scene(menuPane));
   			menu.show();
   		} catch (IOException e) {
   			e.printStackTrace();
   			throw new FileErrorException(
   					"/application/view/ErrorMessageTemplate.fxml");
   		}		
   }

   

    /**
     * Initialises the DisplayResults.fxml file with Game results info from the 
     * event that has just been run.
     * 
     * @param playGame
     */
    public void initialize(PlayGame playGame) {
	this.playGame=playGame;
	//Set heading with EventID
	resultHeading.setText("Results for the event "+playGame.getGameSelectPlay().
			getSetUp().getEventID()+" are as follows");
	//Add new Text with Game results
	for (int i = 0; i < playGame.getGameSelectPlay().getSetUp().
			getCompetitors().size(); i++) {
	    Text j = new Text(Integer.toString(i+1));
	    Text k = new Text(playGame.getGameSelectPlay().getSetUp().
	    		getCompetitors().get(i).getId());
	    Text l = new Text(playGame.getGameSelectPlay().getSetUp().
	    		getCompetitors().get(i).getName());
	    Text m = new Text(Integer.toString(playGame.getGameSelectPlay().
	    		getSetUp().getCompetitors().get(i).getResult())+" seconds");
	    Text n = new Text(Integer.toString(playGame.getGameSelectPlay().
	    		getSetUp().getCompetitors().get(i).getGamePoints()));
	   //Set text style 
	    j.setFont(Font.font("American Typewriter", FontWeight.EXTRA_LIGHT, 13));
	    j.setFill(Color.WHITE);
	    k.setFont(Font.font("American Typewriter", FontWeight.EXTRA_LIGHT, 13));
	    k.setFill(Color.WHITE);
	    l.setFont(Font.font("American Typewriter", FontWeight.EXTRA_LIGHT, 13));
	    l.setFill(Color.WHITE);
	    m.setFont(Font.font("American Typewriter", FontWeight.EXTRA_LIGHT, 13));
	    m.setFill(Color.WHITE);
	    n.setFont(Font.font("American Typewriter", FontWeight.EXTRA_LIGHT, 13));
	    n.setFill(Color.WHITE);
	    //Add text to the result table Grid Pane. 
	    resultTable.add(j,0,i+1);
	    resultTable.add(k,1,i+1);
	    resultTable.add(l,2,i+1);
	    resultTable.add(m,3,i+1);
	    resultTable.add(n,4,i+1);
	}
	
    }
    
}
