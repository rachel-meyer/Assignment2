/**
 * ErrorMessageTemplateController is the controller class for the 
 * ErrorMessageTemplate.fxml file
 * Action events include: acknowledge()
 * Supporting methods include setMessage(), getters and setters for 
 * all accessing classes, 
 */

package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

import application.model.*;
import application.view.*;

public class ErrorMessageTemplateController {
    
    DisplayAllGameResultsController dgrc = new DisplayAllGameResultsController();
    TooFewAthletesException tfae = new TooFewAthletesException();
    FileErrorException fee = new FileErrorException();
    WrongTypeException wte = new WrongTypeException();
    GameFullException gfe = new GameFullException();
    NoRefereeException nre = new NoRefereeException();
    NoGamePresentException ngp = new NoGamePresentException();

    @FXML
    private Button ok;
    
    @FXML
    private Label errorMessage;
    
    /**
     * Sets the relevant error message as called by the class accessing the 
     * ErrorMessageTemplate.fxml file.
     * 
     * @param msg
     */
    public void setMessage(String msg) {
    	errorMessage.setText(msg);
    }
    
    /**
     * Called by the GameResultsController class to give access back to itself.
     * 
     * @param dgrc
     */
    public void setGameResultsController(DisplayAllGameResultsController dgrc) {
    	this.dgrc = dgrc;
    }
    
    /**
     * Called by the TooFewAthletesException class to give access back to itself.
     * 
     * @param tfae
     */
    public void setTooFewAtheletesException(TooFewAthletesException tfae) {
    	this.tfae = tfae;
    }
        
    /**
     * Called by the File ErrorException class to give access back to itself.
     * 
     * @param fee
     */
    public void setFileErrorException(FileErrorException fee) {
    	this.fee = fee;
    }
        
    /**
     * Called by the WrongTypeException class to give access back to itself.
     * 
     * @param wte
     */
    public void setWrongTypeException(WrongTypeException wte) {
    	this.wte=wte;
    }
        
    /**
     * Called by the WrongTypeException class to give access back to itself.
     * 
     * @param gfe
     */
    public void setGameFullException(GameFullException gfe) {
    	this.gfe = gfe;
    }
        
    /**
     * Called by the WrongTypeException class to give access back to itself.
     * 
     * @param nre
     */
    public void setNoRefereeException(NoRefereeException nre) {
    	this.nre=nre;
    }
        
    
    /**
     * Called by the NoGamePresentException class to give access back to itself.
     * 
     * @param ngp
     */
    public void setNoGamePresentException(NoGamePresentException ngp) {
    	this.ngp=ngp;
    }


    /**
     * Action event to close the stage when user acknowledges the message.
     * 
     * @param event
     * @throws FileErrorException
     * @throws IOException
     */
    @FXML
    void acknowledge(ActionEvent event) throws FileErrorException, IOException {
	 Stage stage = (Stage) errorMessage.getScene().getWindow();
	 stage.close();
    }
    
    
 
    
}
