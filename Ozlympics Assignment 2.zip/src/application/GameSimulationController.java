/**
 * GameSimulation Controller is the controller class for the GameSimulation.fxml
 * file.
 * Action events include: race() and seeResults()
 * Supporting methods include: initialize(), simulateGame(), setIncrements(),
 * createProgressBars(), bindProgressBarsToIncrements(), announceWinner()
 * 
 */

package application;

import java.sql.SQLException;

import javax.swing.GroupLayout.Alignment;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Shape;
import javafx.scene.text.*;
import javafx.stage.Stage;
import javafx.util.Duration;


public class GameSimulationController extends Thread {
    
    private PlayGame playGame;
    private Shape shape;

    @FXML 
    private Label title;
    
    @FXML
    private Button seeResults;
    
    @FXML
    private BorderPane borderPane;
    
    @FXML
    private VBox vBox;
    
    @FXML
    private Label winner;
    
   
    public PlayGame getPlayGame(){
    	return playGame;
    }
    
    
	
    /**
     * Loads the DisplayResults.fxml file to view the current games results.
     * 
     * @param event
     */
    @FXML
    void seeResults(ActionEvent event) {
    	System.out.println("Getting results");
	    Stage stage = (Stage) seeResults.getScene().getWindow();
	    stage.close();
	    playGame.getGameSelectPlay().getPlay().
	    displayResults("/application/view/DisplayResults.fxml");
    }

    
    /**
     * Initializes the SimlulateGame.fxml file when it loaded by calling the relevant
     * methods from the PlayGame class to record results of the competition
     * 
     * @param playGame
     * @throws SQLException
     * @throws InterruptedException 
     */
    public void initialize(PlayGame playGame) throws SQLException, InterruptedException {
    	this.playGame=playGame;
    	title.setText("There They Go!!");
	    simulateGame();
	    playGame.getGameSelectPlay().getPlay().setTimestamp();
	    playGame.getGameSelectPlay().getPlay().sortResults();
	    playGame.getGameSelectPlay().getPlay().assignPoints();
	    playGame.getGameSelectPlay().getPlay().makeUpdates();
    }
    
    
	/**
	 * Simulates the game and announces the winner.
	 */
	public void simulateGame() {
		System.out.println("Starting race...");
		TranslateTransition transition = null;
	    for(int i=0; i<playGame.getGameSelectPlay().getSetUp().
	    		getCompetitors().size(); i++) {
	    	shape = new Circle(10, Color.WHITE);
	        vBox.getChildren().add(shape);
	        transition = new TranslateTransition();
	        if(playGame.getGameSelectPlay().getSetUp().
	    		getEventType()=="Running") {
	        transition.setDuration(Duration.seconds(playGame.getGameSelectPlay().
	        		getSetUp().getCompetitors().get(i).getResult()/2));
	        }
	        else if (playGame.getGameSelectPlay().getSetUp().
		    		getEventType()=="Cycling") {
	        	transition.setDuration(Duration.seconds(playGame.
	        			getGameSelectPlay().getSetUp().getCompetitors().get(i).
	        			getResult()/100));
	        }
	        else transition.setDuration(Duration.seconds(playGame.
	        		getGameSelectPlay().getSetUp().
        			getCompetitors().get(i).getResult()/18));
		    		
	        transition.setNode(shape);
	        transition.setToX(280);
	        transition.play();
	    }
	    transition.setOnFinished(e -> announceWinner());
	}


	
	/**
	 * Displays the winner of the event at the end of the game simulation.
	 * @return 
	 */
	public EventHandler<ActionEvent> announceWinner() {
		System.out.println("Getting the winner...");
	  winner.setText("The winner is "+playGame.getGameSelectPlay().
			  getSetUp().getCompetitors().get(0).getName()+"!");
	return null;  

	}
   

}
