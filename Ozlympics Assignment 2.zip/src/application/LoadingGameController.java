/**
 * The LoadingGameController is the controller class for the LoadingGame.fxml file
 * Action events include play()
 * Supporting methods is initialize()
 */

package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import application.model.*;
import application.view.*;


public class LoadingGameController implements Initializable {
    
    public LoadingGameModel loadingGameModel = new LoadingGameModel();
    
    @FXML
    private Button letsPlay;

    @FXML
    private Label loadingGame;
    
    /**
     * Initializes the LoadingGame.fxml file after it has been loaded
     *  with "Let's Play" text.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
	    letsPlay.setText("Let's play!");    
    }

    /**
     * Loads participant data (from Db or text file) and then loads  
     * the Menu.fxml file.
     * 
     * @param event
     * @throws FileErrorException
     * @throws IOException
     */
    @FXML
    void play(ActionEvent event) throws FileErrorException, IOException {
    	try {
    		loadingGameModel.getParticipantData();
    		Stage stage = (Stage) loadingGame.getScene().getWindow();
    		stage.close();
    		Parent root = FXMLLoader.load(getClass().
    				getResource("/application/view/Menu.fxml"));
    		Scene scene = new Scene(root);
    		stage.setScene(scene);
    		stage.show();    
    	} catch (SQLException e) {
    		loadingGame.setText("Game could not load");	    
    		e.printStackTrace();
    		throw new FileErrorException(
    				"/application/view/ErrorMessageTemplate.fxml");
    	} catch (IOException e) {
    		loadingGame.setText("Error with loading the menu");
    		e.printStackTrace();
    		throw new FileErrorException(
    				"/application/view/ErrorMessageTemplate.fxml");
    	}
    }

}