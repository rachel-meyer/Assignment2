/**
 * MakeUpdates class is called within the PlayGame to update the points and
 * game results of athletes for the current event being played.
 * Updates are made to the Athlete ObservableArrayList, the GameResults.txt file
 * and the GameResults table in the OzlympicDb.sqlite database.
 */

package application;

import java.io.*;
import java.sql.*;
import application.model.*;


public class MakeUpdates {
    
    private PlayGame playGame;
    private Connection connection;
    private final String GameResults = "/Users/Rachel/Documents/AdvProgAssignment2"
    		+ "/Ozlympics2/src/application/model/GameResults.txt";
    
    
    
    /**
     * Called by the PlayGame class to allow access back to itself
     * 
     * @param playGame
     */
    public void setPlayGame(PlayGame playGame) {
	this.playGame = playGame;
    }
    
    
    

    /**
     * Updates the allAthletes ArrayList to add game points to total points.
     */
     public void updateAthleteData() {
    	 System.out.println("Updating athlete points...");
    	 for(Athlete c: playGame.getGameSelectPlay().getSetUp().getCompetitors()) {
    		 c.setTotalPoints(c.getTotalPoints());
    		 for(int i=0; i<Athlete.getAllAthletes().size();i++) {
    			 if(c.getId().equals(Athlete.getAllAthletes().get(i).getId())) {
    				 Athlete.getAllAthletes().set(i,c);
    			 }	
    		 }
    	 }
     }
     
     
     /**
      *  Appends game results to GameResults.txt file
      */
    public void printGameResults(){
        try {
        	System.out.println("Writing game results to text file...");
            BufferedWriter writer = new BufferedWriter(new FileWriter(GameResults, true));
            writer.newLine();
            writer.write(playGame.getGameSelectPlay().getSetUp().getEventID()+", ");
            writer.write(playGame.getGameSelectPlay().getSetUp().
            		getReferee().getId()+", ");
            writer.write(playGame.getTimestamp());
            writer.newLine();
            for(Athlete x: playGame.getGameSelectPlay().getSetUp().getCompetitors()) {
            	writer.write(x.getId()+", ");
            	writer.write(x.getResult()+", ");
            	writer.write(x.getGamePoints()+" ");
            	writer.newLine();
            }
            writer.flush();
            writer.close();   	
            } catch (IOException e) {
               e.printStackTrace();
               System.out.println("Error with Game Results File");
            }
     }
    
    
    /**
     * Connects to the SQLite database and sets up the query to load game results
     * into the GameResults table.
     * 
     * @param eventID
     * @param refereeID
     * @param competitorID
     * @param result
     * @param gamePoints
     * @return
     * @throws SQLException
     */
    public boolean setUploadGameResult(String eventID, String refereeID,
    		String competitorID, int result, int gamePoints) throws SQLException {
    	connection = DbConnection.Connector("org.sqlite.JDBC");
    	PreparedStatement preparedStatement =null;
    	String query = "Insert into GameResults (eventID, officialID, athleteID,"
    			+ " result, gamePoints) VALUES (?,?,?,?,?)";
    	try {  
  	      	preparedStatement = connection.prepareStatement(query);   
  	      	preparedStatement.setString(1, eventID);
  	      	preparedStatement.setString(2, refereeID);
  	      	preparedStatement.setString(3, competitorID);
  	      	preparedStatement.setInt(4, result);
  	      	preparedStatement.setInt(5, gamePoints);
  	      	preparedStatement.executeUpdate();
  	      	return true;
  	    } catch (Exception e) {
  	    	e.printStackTrace();
  	    	return false;
  	    } finally {
  	//	preparedStatement.close();
  	    }
     }

    
    /**
     * Appends the game results to the GameResults table
     * 
     * @throws SQLException
     */
    public void updateGameResults() throws SQLException {
    	System.out.println("Writing game results to database...");
    	for (int i=0; i<playGame.getGameSelectPlay().getSetUp().
    			getCompetitors().size(); i++){
    		setUploadGameResult(playGame.getGameSelectPlay().getSetUp().getEventID(),
    				playGame.getGameSelectPlay().getSetUp().getReferee().getId(), 
    				playGame.getGameSelectPlay().getSetUp().getCompetitors().
    				get(i).getId(),
    				playGame.getGameSelectPlay().getSetUp().getCompetitors().
    				get(i).getResult(),
    				playGame.getGameSelectPlay().getSetUp().getCompetitors().
    				get(i).getGamePoints());
       }
    }



    

}
