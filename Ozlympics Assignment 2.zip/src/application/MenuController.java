/**
 * MenuController class is the controller class for the Menu.fxml file. 
 * It executes decisions by the user in the menu.
 * Action events include setUpGame(), playGame(), displayGameResults(), 
 * displayAthletePoints(), exit().
 * Supporting methods include loadMenu(),
 */

package application;

import java.io.IOException;
import application.model.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class MenuController {
    
    private Game game;
    private PlayGame play;
   
    
    @FXML
    private RadioButton setUpGame;

    @FXML
    private RadioButton playGame;

    @FXML
    private RadioButton displayGameResults;

    @FXML
    private RadioButton displayAthletePoints;

    public Game getGame() {
    	return game;
    }

    
    /**
     * Adds a game to the ArrayList of games and calls the method to setup that game.
     * 
     * @param event
     * @throws IOException
     * @throws IllegalStateException
     * @throws FileErrorException
     */
    @FXML
    void setUpGame(ActionEvent event) 
    		throws IOException, IllegalStateException, FileErrorException {
    	Stage stage = (Stage) setUpGame.getScene().getWindow();
    	stage.close();
	    Game.getAllGames().add(new Game());
	    game = Game.getAllGames().get(Game.getAllGames().size()-1);
	    try {
	    	System.out.println("Setting up a game");
			game.setUpGame(game);
		} catch (Exception e) {
			e.printStackTrace();
		}	
    }
    
    
    /**
     * Checks to see if there are games to play. If there are, calls the method in 
     * the Game class to play the game. Otherwise loads an error message and re-loads
     * the menu.
     * 
     * @param event
     * @throws NoGamePresentException
     * @throws IOException
     * @throws FileErrorException 
     */
    @FXML
    void playGame(ActionEvent event) 
    		throws NoGamePresentException, IOException, FileErrorException {
    	Stage stage = (Stage) playGame.getScene().getWindow();
    	stage.close();
    	if(Game.getAllGames().size()==0) {
    		loadMenu();
    		throw new NoGamePresentException (
    				"/application/view/ErrorMessageTemplate.fxml");
	    } else {
	    	play = new PlayGame();
	    	play.selectGame();
		}	
    }
    
    
    /**
     * Creates a new instance of the Official class. Calls the relevant method in 
     * the Offical class to display all of the Athletes current total points.
     * 
     * @param event
     * @throws IOException
     * @throws FileErrorException 
     */
    @FXML
    void displayAthletePoints(ActionEvent event) 
    		throws IOException, FileErrorException {
    	System.out.println("Displaying Athlete Total Points...");
    	Stage stage = (Stage) displayAthletePoints.getScene().getWindow();
    	stage.close();
    	Official o2 = new Official();
    	o2.summarisePoints("/application/view/DisplayAthletePoints.fxml");	
    }
    
    
    /**
     * Creates a new instance of the Official class. Calls the relevant method in 
     * the Offical class to display all of the results of games played so far.
     * 
     * @param event
     * @throws FileErrorException
     */
    @FXML
    void displayGameResults(ActionEvent event) throws FileErrorException {
    	System.out.println("Displaying all game results...");
    	displayGameResults.getScene().getWindow().hide();
    	Official o1 = new Official();
    	o1.summariseGames("/application/view/DisplayAllGameResults.fxml");
    }

    
    /**
     * Exits the program
     * 
     * @param event
     */
    @FXML
    void exit(ActionEvent event) {
	System.out.println("Thanks for playing! See you next time :-)");
	    System.exit(0);
    }


    /**
     * Loads the Menu.fxml file. This method is called by the playGame() method.
     */
    public void loadMenu() {
    	try {
    		System.out.println("Going back to the menu...");
    		Stage stage = (Stage) playGame.getScene().getWindow();
    		stage.close();
    		Parent menuPane = (AnchorPane) FXMLLoader.load(Ozlympic.class.
    				getResource("/application/view/Menu.fxml"));
    		Stage menu = new Stage();
    		menu.setScene(new Scene(menuPane));
    		menu.show();
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    }

}

