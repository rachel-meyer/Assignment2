/**
 * The Ozlympic program is for running a set of games called the "Ozlympic Games"
 * The Ozlympic class is the main start up class.
 * The program can:
 * Allow the user to set up a game
 * Allow the user to select a game to run (if it hasn't already been run)
 * Allow the user to predict the winner of the game
 * Run a game and award points for the top 3 competitors
 * Display a congratulation message if the user prediction is correct.
 * Display the final result of all games including the name of the referee for each game.
 * Display the points of athletes.
 * 
 * @author Rachel Meyer - s3403023
 */

package application;


import java.io.IOException;
import javafx.application.Application;
import application.model.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.stage.Stage;


public class Ozlympic extends Application {

    /**
     * Loads the LoadingGame.fxml file
     * 
     * @param primaryStage
     * @exception FileErrorException
     * @exception IOException
     */
	public void start(Stage primaryStage) throws FileErrorException, IOException {
		try {
			Parent root = FXMLLoader.load(getClass().
					getResource("/application/view/LoadingGame.fxml"));
			Scene scene = new Scene(root);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
		    System.out.println("Can't find file");
			e.printStackTrace();
			throw new FileErrorException(
					"/application/view/ErrorMessageTemplate.fxml");
		}
	}
  
	
    public static void main(String[] args) {
    	System.out.println("Launching game");
    	Application.launch(args); 
    }
	
}
    
    
   
    




    

    
