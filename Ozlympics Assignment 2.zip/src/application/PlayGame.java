/**
 * The PlayGame class:
 * 1/ allows the user to select which game they wish to play in the game ArrayList
 * 2/ runs the game
 * 3/ sorts the competitors based on the results of the game from best to worst
 * 4/ assigns points for the game
 * 5/ displays results of the game
 * 6/ updates the Athlete ArrayList to add the athletes' points for the game 
 * 7/ updates the GameResults.txt file. Updates the GameResults table in the database
 * 
 */
package application;

import java.util.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import application.model.*;
import java.io.*;
import java.sql.*;
import java.text.*;


public class PlayGame {
    
    public PlayGame() {
    }
	
	public PlayGame(Game game) {
		this.game = game;
    }
    
    private Game game;
    private MakeUpdates makeUpdates;
    private Game gameSelectPlay;
    private String timestamp;
    private PlayGame playGame;
    
    
    public Game getGameSelectPlay() {
    	return gameSelectPlay;
    }
    
    public void setGameSelectPlay(Game gameSelectPlay) {
        this.gameSelectPlay = gameSelectPlay;
    }
    
    public void setPlay(PlayGame playGame) {
        this.playGame=playGame;
    }
    
    public Game getGame(){
    	return game;
    }

    public MakeUpdates getMakeUpdates() {
    	return makeUpdates;
    }

   public String getTimestamp() {
	   return timestamp;
   }
   
   
   /**
    * Creates a timestamp for the current game.
    */
   public void setTimestamp() {
	   System.out.println("Setting timestamp...");
   	timestamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
   }
   
  
   /**
    * Loads the SelectGame.fxml file so that user can choose a game to play.
    * 
    * @throws NoGamePresentException
    * @throws FileErrorException 
    */
   public void selectGame() throws NoGamePresentException, FileErrorException {
	   try {
		   System.out.println("Selecting game to play...");
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(PlayGame.class.
            		getResource("/application/view/SelectGame.fxml"));
            AnchorPane selectGame = (AnchorPane) loader.load();
            Scene scene = new Scene(selectGame);
            SelectGameController controller = loader.getController();
            controller.initialize(this);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
            controller.checkForGames();
	    }  catch (IOException e) {
		e.printStackTrace();
	    }
     }
    
    
    /**
     * Runs the selected game by calling the compete method (declared in
     * Athlete class). Sets the game points to 0 beforehand,
     * in case the game has already been run before. 
     */
   public void compete() {   
	   for (Athlete c: gameSelectPlay.getSetUp().getCompetitors()) {
		   c.setGamePoints(0);
		   c.compete();
	   }
   }
    
    
    /**
     * Sorts the competitors based on their results.
     */
     public void sortResults() {
         Collections.sort((List<Athlete>) gameSelectPlay.getSetUp().
        	           getCompetitors(), new Comparator<Athlete>() {
        	 public int compare(Athlete result1, Athlete result2) {
        		 return result1.getResult().compareTo(result2.getResult());
        	 }
         }); 
      }
     
     
    /**
     * Assigns points based on the results for the game.
     */
    public void assignPoints() {
    	System.out.println("Assigning points for the game...");
        for (int i=0; i<gameSelectPlay.getSetUp().getCompetitors().size(); i++) {
            if(i==0) {
                gameSelectPlay.getSetUp().getCompetitors().get(i).
                setGamePoints(5);
             } else if (i==1) {
                 gameSelectPlay.getSetUp().getCompetitors().get(i).
                 setGamePoints(2);
             } else if (i==2) {
                 gameSelectPlay.getSetUp().getCompetitors().get(i).
                 setGamePoints(1);
             } else if (i>2) { 
            	 gameSelectPlay.getSetUp().getCompetitors().get(i).
            	 setGamePoints(0);
            }
        }    
    }
    
    
    /**
     * Updates Athlete data game results data. See class for more details
     * @throws SQLException
     */
    public void makeUpdates() throws SQLException {
    	makeUpdates  = new MakeUpdates();
    	makeUpdates.setPlayGame(this);
    	makeUpdates.updateAthleteData();
    	makeUpdates.printGameResults();
    	makeUpdates.updateGameResults();
    }
    
    
    /**
     * Loads the SimulateGame.fxml in order to simulate the game.
     * 
     * @param fileName
     * @throws SQLException
     * @throws InterruptedException 
     */
    public void simulateGame(String fileName) throws SQLException, InterruptedException {
    	try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(PlayGame.class.getResource(fileName));
            AnchorPane simulateGame = (AnchorPane) loader.load();
            Scene scene = new Scene(simulateGame);
            GameSimulationController controller = loader.getController();
            controller.initialize(this);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
	    	}  catch (IOException e) {
	    		e.printStackTrace();
	    	}
    }

    
    /**
     * Loads the DisplayResults.fxml file to show the results of the most
     * recent event
     * 
     * @param fileName
     */
    public void displayResults(String fileName) {
    	try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(PlayGame.class.getResource(fileName));
            AnchorPane displayResults = (AnchorPane) loader.load();
            Scene scene = new Scene(displayResults);
            DisplayResultsController controller = loader.getController();
            controller.initialize(this);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
    		} catch (IOException e) {
    			e.printStackTrace();
    		}
    }
     
}
