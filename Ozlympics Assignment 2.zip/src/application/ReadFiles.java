/**
 * The ReadFiles class reads the Participant.txt file if the database doesn't 
 * connect as it should, and adds the data to the relevant ArrayList.
 */

package application;

import java.io.*;
import java.util.HashSet;
import java.util.Set;

import application.model.*;


public class ReadFiles {

    private final String ParticipantFile = "/Users/Rachel/Documents/AdvProgAssignment2/"
    		+ "Ozlympics2/src/application/model/ParticipantData.txt";

    
    /**
     * Reads in Participant data, splits it by a comma delimeter and adds the data
     * to the relevant ArrayList
     * @throws IOException  
     */
    public void setParticipants() throws FileErrorException, IOException {
    	try {
    		System.out.println("Reading Participants from text file...");
    		BufferedReader br = new BufferedReader(new FileReader(ParticipantFile));
    		String line=null;
    		while((line=br.readLine())!=null){
   				String a[]=line.split(", ");
   				if((a[0].equals(""))||(a[1].equals(""))||(a[2].equals(""))||
   						(a[3].equals(""))||(a[4].equals(""))) {
   					continue;
   				} else if (!(a[4].equals("Officer"))) {
    				Athlete.getAllAthletes().add(new Athlete(a[0],a[1],
    						Integer.parseInt(a[2]),a[3],a[4]));
    			} else if (a[4].equals("Officer")) {
   					Official.getAllOfficials().add(new Official(a[0],a[1],
   						Integer.parseInt(a[2]),a[3],a[4]));
   				} 
   			} 
    		br.close();
    	} catch (IOException e) {
    		throw new FileErrorException(
    				"/application/view/ErrorMessageTemplate.fxml");
    	} catch (Exception e) {
    		System.out.println("There was an error");
    	}
   }
    
}	 
