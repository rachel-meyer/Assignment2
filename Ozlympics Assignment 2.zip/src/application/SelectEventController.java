/**
 * SelectEventController is the controller class for the SelectEvent.fxml file
 * User can choose cycling, swimming or running.
 * Action events are selectCycling(), selectSwimming(), selectRunning() and
 * backToMenu().
 */

package application;

import java.io.*;
import application.model.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class SelectEventController {
	
	private SetUpGame setUpGame;

    @FXML
    private RadioButton swimmingEvent;

    @FXML
    private RadioButton cyclingEvent;

    @FXML
    private RadioButton runningEvent;

    @FXML
    private Button backToMenu;
    
    /**
     * Called by the SetUpGame class to allow access back to itself
     * 
     * @param setUpGame
     */
    public void setSetUpGame (SetUpGame setUpGame) {
    	this.setUpGame=setUpGame;
    }

    /**
     * Sends user back to the initial menu.
     * 
     * @param event
     */
    @FXML
    void backToMenu(ActionEvent event) throws FileErrorException, IOException {
    	System.out.println("Going back to menu...");
    		try {
    			Stage stage = (Stage) backToMenu.getScene().getWindow();
    			stage.close();
    			Parent menuPane = (AnchorPane) FXMLLoader.load(Ozlympic.class.
    					getResource("/application/view/Menu.fxml"));
    			Stage menu = new Stage();
    			menu.setScene(new Scene(menuPane));
    			menu.show();
    		} catch (IOException e) {
    			e.printStackTrace();
    			throw new FileErrorException(
    					"/application/view/ErrorMessageTemplate.fxml");
    		}		
    }

    
    /**
     * Sets eventType to cycling when user selects this option.
     * Creates a new eventID
     * Loads the ChooseCompetitors.fxml as next step to setup the game.
     * 
     * @param event
     * @throws IOException
     * @throws FileErrorException
     * @throws IllegalStateException
     */
    @FXML
    void selectCycling(ActionEvent event) 
    		throws IOException, FileErrorException, IllegalStateException {
    	System.out.println("Selected event is cycling");
    	setUpGame.setEventType("Cycling");
    	Stage stage = (Stage) cyclingEvent.getScene().getWindow();
    	stage.close();
    	setUpGame.setEventID();
    	setUpGame.setValidAthlete();
    	try {
    		setUpGame.showCompetitors("/application/view/ChooseCompetitors.fxml");
    	} catch (Exception e) {
    		e.printStackTrace();
    	}		
    }

    
    /**
     * Sets eventType to running when user selects this option.
     * Creates a new eventID
     * Loads the ChooseCompetitors.fxml as next step to setup the game.
     * 
     * @param event
     * @throws IOException
     * @throws FileErrorException
     * @throws IllegalStateException
     */
    @FXML
    void selectRunning(ActionEvent event) 
    		throws IOException, FileErrorException, IllegalStateException {
    	System.out.println("Selected event is Running");
    	setUpGame.setEventType("Running");
    	Stage stage = (Stage) runningEvent.getScene().getWindow();
    	stage.close();
    	setUpGame.setEventID();
    	setUpGame.setValidAthlete();
    	try {
    		setUpGame.showCompetitors("/application/view/ChooseCompetitors.fxml");
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    }


    /**
     * Sets eventType to swimming when user selects this option.
     * Creates a new eventID
     * Loads the ChooseCompetitors.fxml as next step to setup the game.
     * 
     * @param event
     * @throws IOException
     * @throws FileErrorException
     * @throws IllegalStateException
     */
    @FXML
    void selectSwimming(ActionEvent event) 
    		throws IOException, FileErrorException, IllegalStateException {
    	System.out.println("Selected event is swimming");
    	setUpGame.setEventType("Swimming"); 
    	Stage stage = (Stage) swimmingEvent.getScene().getWindow();
    	stage.close();
    	setUpGame.setEventID();
    	setUpGame.setValidAthlete();
    	try {
    		setUpGame.showCompetitors("/application/view/ChooseCompetitors.fxml");
    	} catch (Exception e) {
		e.printStackTrace();
    	}
    }

    
    
}

