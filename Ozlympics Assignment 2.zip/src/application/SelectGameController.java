/**
 * SelectGameController is the controller class for SelectGame.fxml file.
 * It allows the user to choose which game s/he wants to play. 
 */

package application;

import java.io.*;
import java.sql.*;
import java.util.*;
import application.model.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;

public class SelectGameController {
    
	private PlayGame playGame;
    private ArrayList<RadioButton> radioButton  = new ArrayList<RadioButton>();
    private ArrayList<Label> ids= new ArrayList<Label>();
    private ArrayList<Label> names= new ArrayList<Label>();
    private ArrayList<Label> types= new ArrayList<Label>();
    private RadioButton event;
   
    @FXML
    private VBox gameOptions;

    @FXML
    private Label eventType;

    @FXML
    private Label referee;

    @FXML
    private Label numberOfCompetitors;

    @FXML
    private GridPane competitorDetails;

    @FXML
    private Button submitGame;

    @FXML
    private Button backToMenu;
    
    @FXML
    private AnchorPane selectGamePane;
    
    
    /**
     * Initialises the SelectGame.fxml file after it's been loaded by adding new
     * radio buttons for events that have not yet been played and have competitors.
     * Then calls instantiateCompetitorLabels() and gameChoice()
     * @param playGame
     */
    public void initialize(PlayGame playGame) {
    	this.playGame=playGame;
    	for (int i=0; i<Game.getAllGames().size(); i++){
    	    if((Game.getAllGames().get(i).getSetUp().getCompetitors().size()==0)){
    	    	continue;
    	    } else if ((Game.getAllGames().get(i).getSetUp().
    	    		getCompetitors().get(0).getResult()!=0)){
    	    	continue;
    	    } else {
    	    	event = new RadioButton(Game.getAllGames().get(i).
    	    			getSetUp().getEventID());
    	    }  
    	    radioButton.add(event);
    	    gameOptions.getChildren().add(event);
    	}
    	instantiateCompetitorLabels();
    	gameChoice();
    }
    	

    /**
     * Called by the PlayGame class when SelectGame.fxml is loaded to see if there
     * are any games set up that can be played. Loads an error message if there
     * are no games that can be played.
     * 
     * @throws NoGamePresentException
     * @throws IOException
     * @throws FileErrorException 
     */
    @FXML
    void checkForGames() 
    		throws NoGamePresentException, IOException, FileErrorException {
    	System.out.println("Checking for games that can be played...");
    	if (gameOptions.getChildren().isEmpty()) {
    		Stage check = (Stage) gameOptions.getScene().getWindow();
    		check.close();
    		loadMenu();
    		throw new NoGamePresentException(
    				"/application/view/ErrorMessageTemplate.fxml");	 
    	}	     
    }


    /**
     * Calls the loadMenu() which sends user back to the initial menu.
     * 
     * @param event
     * @throws FileErrorException
     * @throws IOException
     */
    @FXML
    void backToMenu(ActionEvent event) throws FileErrorException, IOException {
    	loadMenu();
    }
    
    
    public void loadMenu() throws FileErrorException, IOException {
 		try {
 			System.out.println("Going back to the menu...");
   			Stage stage = (Stage) backToMenu.getScene().getWindow();
   			stage.close();
   			Parent menuPane = (AnchorPane) FXMLLoader.load(Ozlympic.class.
   					getResource("/application/view/Menu.fxml"));
   			Stage menu = new Stage();
   			menu.setScene(new Scene(menuPane));
   			menu.show();
   		} catch (IOException e) {
   			e.printStackTrace();
   			throw new FileErrorException(
   					"/application/view/ErrorMessageTemplate.fxml");
   		}		
   }

    
    
    /**
     * Calls the compete() method in the PlayGame class to generate the competitor
     * results. Calls the simulateGame() method in the PlayGame class which loads
     * the GameSimulation.fxml file to simulate the game.
     * 
     * @param event
     * @throws SQLException
     * @throws InterruptedException 
     */
    @FXML
    void submitGame(ActionEvent event) throws SQLException, InterruptedException {
    	System.out.println("Submitting game to play...");
	    playGame.getGameSelectPlay().getPlay().compete();
		playGame.getGameSelectPlay().getPlay().
			simulateGame("/application/view/GameSimulation.fxml");
		Stage stage = (Stage) submitGame.getScene().getWindow();
		stage.close();
	}

   
    /**
     * set the font and style of the radio button text.
     * sets an action for the radio button: calls showGameDetails() and 
     * showCompetitorDetails()
     */
	public void  gameChoice() {
		for(int i=0; i<radioButton.size(); i++) {
			for (Game g : Game.getAllGames()) {
				if(g.getSetUp().getEventID()==null) {
					continue;
				} else if(g.getSetUp().getEventID().equals(radioButton.
						get(i).getText())) {
					radioButton.get(i).setFont(Font.
							font("American Typewriter", FontWeight.LIGHT, 13));
					radioButton.get(i).setStyle("-fx-text-fill:WHITE");
					radioButton.get(i).setOnAction(e -> {
						playGame.setGameSelectPlay(g);
						playGame.getGameSelectPlay().setPlay(playGame);
						try {
							System.out.println("Getting game details...");
							showGameDetails(g);
							showCompetitorsDetails(g);
						} catch (NoRefereeException |
								IOException | 
								IllegalStateException | 
								FileErrorException e1) {
								e1.printStackTrace();
						}
					});
				}
			}    
		}
    }

	/**
	 * Creates new labels for the competitor details and adds the labels
	 * to competitorDetails GridPane.
	 */
    public void instantiateCompetitorLabels() {
	    for (int i = 0; i < 8; i++){
		Label j = new Label();
		ids.add(j);
		Label k = new Label();
		names.add(k);
		Label l = new Label();
		types.add(l);
		     competitorDetails.add(j, 0, i+1);
		     competitorDetails.add(k,1,i+1);
		     competitorDetails.add(l, 2, i+1);
	    }
    }
	
    

    /**
     * Checks to see if the game has a referee. If no referee loads error 
     * message and re-loads the ChooseReferee.fxml file.
     * 
     * @param game
     * @throws NoRefereeException
     * @throws IOException
     * @throws IllegalStateException
     * @throws FileErrorException
     */
    public void showGameDetails(Game game) 
    		throws NoRefereeException, IOException, 
    		IllegalStateException, FileErrorException {
    	if (playGame.getGameSelectPlay().getSetUp().getReferee()==null) {
    		Stage stage = (Stage) submitGame.getScene().getWindow();
			stage.close();
			playGame.getGameSelectPlay().getSetUp().chooseReferee(
					 "/application/view/ChooseReferee.fxml");
			  throw new NoRefereeException(
			  		 "/application/view/ErrorMessageTemplate.fxml");
		   } else {
	            eventType.setText(playGame.getGameSelectPlay().
	            		getSetUp().getEventType());
	            referee.setText(playGame.getGameSelectPlay().
	            		getSetUp().getReferee().getName());
	            numberOfCompetitors.setText(Integer.toString(playGame.
	            		getGameSelectPlay().getSetUp().getCompetitors().size())); 
	       }	    
    }
    
    /**
     * Clears previous competitor details and sets competitor details for the
     * currently selected game.
     * 
     * @param game
     */
    public void showCompetitorsDetails(Game game) {
    	for (int i = 0; i < playGame.getGameSelectPlay().getSetUp().
    			getCompetitors().size(); i++){
    		ids.get(i).setText(" ");
    		names.get(i).setText(" ");
	     	types.get(i).setText(" ");
		}
	 for (int i = 0; i < playGame.getGameSelectPlay().getSetUp().
			 getCompetitors().size(); i++){
	     ids.get(i).setText(playGame.getGameSelectPlay().getSetUp().
	    		 getCompetitors().get(i).getId());
	     names.get(i).setText(playGame.getGameSelectPlay().getSetUp().
	    		 getCompetitors().get(i).getName());
	     types.get(i).setText(playGame.getGameSelectPlay().getSetUp().
	    		 getCompetitors().get(i).getType());
	     ids.get(i).setFont(Font.font("American Typewriter", 
	    		 FontWeight.LIGHT, 13));
	     ids.get(i).setTextFill(Color.WHITE);
	     names.get(i).setFont(Font.font("American Typewriter",
	    		 FontWeight.LIGHT, 13));
	     names.get(i).setTextFill(Color.WHITE);
	     types.get(i).setFont(Font.font("American Typewriter", 
	    		 FontWeight.LIGHT, 13));
	     types.get(i).setTextFill(Color.WHITE);
		}
    }
    
    

    


}
