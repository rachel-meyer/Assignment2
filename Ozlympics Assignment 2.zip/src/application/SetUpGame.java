/**
 * The SetUpGame class is used to setup a game including:
 * 1/ Selecting the event type(Swimming, Cycling, or Swimming)
 * 2/ Selecting athletes for the game
 * 3/ Selecting a referee for the game
 */

package application;

import java.io.IOException;
import java.net.URL;
import java.util.*;
import application.model.*;
import application.view.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;


public class SetUpGame {

    private String eventID;
    private String eventType;
    private Official referee; 
    private static int eventNum;
    private Game game;
    private ArrayList<Athlete> competitors  = new ArrayList<Athlete>();
    private SetUpGame setUpGame;
    private String athleteType; 
    
    
    public SetUpGame() {
    }
    
    /**
     * Called by the Game class to allow access back to itself
     * @param game
     */
    public SetUpGame(Game game) {
    	this.game = game;
    }

    
    public SetUpGame getSetUpGame() {
    	return setUpGame;
    }


    public ArrayList<Athlete> getCompetitors() {
    	return competitors;
    }
    
    
    public static int getEventNum() {
    	return eventNum;
    }

    public static void setEventNum() {
    	eventNum++;
   }
    
    public static void resetEventNum(int num) {
    	eventNum = num;
    }
    
    public void setEventID() {
    	System.out.println("Setting Event ID...");
    	setEventNum();
    	eventID=String.valueOf(eventType+eventNum);
    }  
    
    public String getEventID() {
    	return eventID;
    }
    
    public String getEventType() {
    	return eventType;
    }
    
    
    public void setEventType(String eventType) {
    	this.eventType = eventType;
    }
        
      
    public Official getReferee() {
    	return referee;
    }
    
    public void setReferee(Official referee) {
    	this.referee = referee;
    }
   
    /**
     * Assigns the correct athlete type to the event type.
     */
    public void setValidAthlete() {
    	if(eventType.equals("Running")){
    		athleteType="Sprinter";	
    	} else if (eventType.equals("Cycling")){
    		athleteType="Cyclist";	
    	} else if (eventType.equals("Swimming")){
    		athleteType="Swimmer";	
    	} 
    }
    
    public String getValidAthlete() {
    	return athleteType;
    }
    
    
    /**
     * Loads the SelectEvent.fxml file
     * User chooses which kind of event s/he wants to setup. 
     */
    public void showEventOptions(String fileName) 
    		throws IOException, FileErrorException, IllegalStateException {
    	try {
    		System.out.println("Selecting event...");
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(SetUpGame.class.getResource(fileName));
            AnchorPane selectEvent = (AnchorPane) loader.load();
            Scene scene = new Scene(selectEvent);
            SelectEventController controller = loader.getController();
            controller.setSetUpGame(this);    
            Stage event = new Stage();
            event.setScene(scene);
            event.show();
    	}  catch (IOException e) {
    		e.printStackTrace();
    		throw new FileErrorException(
    				"/application/view/ErrorMessageTemplate");
	    }
    }
    

   /**
    * Loads the list of athletes, so that the user can choose which athletes
    * s/he wants to compete in the game.
    * 
    * @param fileName
    * @throws IOException
    * @throws FileErrorException
    * @throws IllegalStateException
    */
    public void showCompetitors (String fileName) 
    		throws IOException, FileErrorException, IllegalStateException {
    	try {
    		System.out.println("Selecting competitors...");
    		FXMLLoader loader = new FXMLLoader();
    		loader.setLocation(SetUpGame.class.getResource(fileName));
    		BorderPane rootLayout = (BorderPane) loader.load();
    		ChooseCompetitorsController controller = loader.getController();   	 
    		controller.setSetUpGame(this);
    		controller.initialize();  
     	 	Stage showCompetitors = new Stage();
     	 	showCompetitors.setScene(new Scene(rootLayout));
     	 	showCompetitors.show();   
    	} catch (IOException e){
    		e.printStackTrace();
    		throw new FileErrorException("/application/view/ErrorMessageTemplate");
    	}
     }
    
 
    /**
     * Loads the list of officials, so that the user can choose which referee
     * s/he wants to officiate the game.
     * 
     * @param fileName
     * @throws FileErrorException
     * @throws IOException
     * @throws IllegalStateException
     */
    public void chooseReferee(String fileName) 
    		throws FileErrorException, IOException, IllegalStateException {
    	try {
    		System.out.println("Selecting Referee...");
    		FXMLLoader loader = new FXMLLoader();
            loader.setLocation(SetUpGame.class.getResource(fileName));
            AnchorPane selectRef = (AnchorPane) loader.load();
            Scene scene = new Scene(selectRef);
            ChooseRefereeController controller = loader.getController();
            controller.setSetUpGame(this);
            Stage ref = new Stage();
            ref.setScene(scene);
            ref.show();
    		}  catch (IOException e) {
    			e.printStackTrace();
    			throw new FileErrorException(
    					"/application/view/ErrorMessageTemplate");
    		}
    }
    
}
