/**
 * The Athlete class contains attributes and a constructor to support creation of an Athlete object.
 * Most of the attributes are common its super class, Participant. 
 * The allAthletes ObservableArrayList is for keeping all of the athletes' details.
 */

package application.model;

import javafx.beans.property.*;
import javafx.collections.*;

public class Athlete extends Participant {
    
    private Integer gamePoints;
    private int result;
    private final IntegerProperty totalPoints;
    private static ObservableList<Athlete> allAthletes = FXCollections.observableArrayList();


    public Athlete (String id, String name, int age, 
	            String state, String type){
    	super(id, name, age, state, type);
    	this.totalPoints= new SimpleIntegerProperty(0);
    }
    
    public Athlete() {
    	super(null,null,0,null,null);
    	this.totalPoints = new SimpleIntegerProperty(0); ;
    }
    
    public Athlete (String id, String name, int age, 
            String state, String type, Integer points){
    	super(id, name, age, state, type);
    	this.totalPoints= new SimpleIntegerProperty(points);
    }
        
    public static ObservableList<Athlete> getAllAthletes() {
    	return allAthletes;
    }
    
    
    public int getTotalPoints() {
        return totalPoints.get();
    }

    public void setTotalPoints(int totalPoints) {
        this.totalPoints.set(totalPoints+gamePoints);
    }

    public IntegerProperty totalPointsProperty() {
        return totalPoints;
    }
    
    public StringProperty totalPointsPropertyString() {
    	return null;	
    }
    
    public Integer compete() {
    	return result;
    }
    
    public Integer getResult() {
    	return result;
    }

    public int getGamePoints() {
    	return gamePoints;
    }

    public void setGamePoints(int gamePoints) {
    	this.gamePoints = gamePoints;
    }

    public void setResult(int result) {
    	this.result=result;
    }

    
}  
   