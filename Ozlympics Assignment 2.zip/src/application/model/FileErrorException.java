/**
 * FileErrorException class loads the file error message via the 
 * ErrorMessageTemplate.fxml file 
 */

package application.model;

import java.io.IOException;  
import application.*;
import application.ErrorMessageTemplateController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
    
public class FileErrorException extends Exception{
    
    public FileErrorException() {
      }
    
    public FileErrorException(String fileName) throws IOException {
    	try {
    		FXMLLoader loader = new FXMLLoader();
    		loader.setLocation(SetUpGame.class.getResource(fileName));
    		AnchorPane errorMessage = (AnchorPane) loader.load();
        	Stage error = new Stage();
        	error.setScene(new Scene(errorMessage));
        	error.setTitle("Error Occured");
        	ErrorMessageTemplateController controller = loader.getController();
        	controller.setFileErrorException(this); 
        	controller.setMessage("There was a problem with loading this part of "
        			+ "the game. Please try re-loading the game");
        	error.show();
        	System.exit(0);
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    }
}

  
    


