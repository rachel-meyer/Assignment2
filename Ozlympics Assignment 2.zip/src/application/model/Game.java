/**
 * The Game class sets up a game and plays a game based on user choices
 * The game is added to the game ArrayList. 
 */

package application.model;

import java.io.IOException;
import java.util.ArrayList;
import application.*;

public class Game{
    
    private static ArrayList<Game> allGames = new ArrayList<Game>();
    private SetUpGame setup;
    private PlayGame play;

    public SetUpGame getSetUp(){
	return setup;
    }
    
    public PlayGame getPlay() {
	return play;
    }
    
    public void setPlay(PlayGame play) {
	this.play=play;
    }
    
    
    public static ArrayList<Game> getAllGames() {
	return allGames;
    }
    
   
    /**
     * Sets up a game. See class for details. Calls the first method to set
     * up the game.
     */
    public void setUpGame(Game game) 
    		throws IllegalStateException, IOException, FileErrorException {
    	setup = new SetUpGame(this);
    	setup.showEventOptions("/application/view/SelectEvent.fxml");
    }
    
    
    /** Plays a game that is stored in the game ArrayList based on user's 
     * choices. See class for details.
     */
    public void playGame() throws NoGamePresentException, FileErrorException {
	play = new PlayGame();
	play.selectGame();
	}
     
}
