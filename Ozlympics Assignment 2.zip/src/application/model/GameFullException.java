/**
 * GameFullException class loads the game full error message via the 
 * ErrorMessageTemplate.fxml file 
 */
package application.model;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import application.*;

public class GameFullException extends Exception{
    

    public GameFullException() {
    }
    
    public GameFullException(String fileName) throws IOException {
    	try {
    		FXMLLoader loader = new FXMLLoader();
            loader.setLocation(SetUpGame.class.getResource(fileName));
            AnchorPane errorMessage = (AnchorPane) loader.load();
            Stage error = new Stage();
            error.setScene(new Scene(errorMessage));
            error.setTitle("Error Occured");
            ErrorMessageTemplateController controller = loader.getController();
            controller.setGameFullException(this); 
            controller.setMessage("Oops! You have selected too many athletes for "
            		+ "this event. Please go back and re-select your competitors");
            error.show();
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    }

}

