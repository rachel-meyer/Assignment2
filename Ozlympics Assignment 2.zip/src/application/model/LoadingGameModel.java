/**
 * LoadingGameModel class calls the Connector() method to connect to the database,
 * checks whether the database is connected and loads Participant data.
 */

package application.model;

import java.io.IOException;
import java.sql.*;
import application.*;

public class LoadingGameModel {
    
    Connection connection;
    
    public LoadingGameModel(){
	connection = DbConnection.Connector("org.sqlite.JDBC");
    }
    
    /**
     * Check connection
     * 
     * @return
     */
    public boolean isDbConnected() {
    	try {
    		if(connection==null) {
    			return false;
    		} else return !connection.isClosed();
    		} catch (SQLException e) {
    			e.printStackTrace();
    			return false;
    		}
    }
    
    /**
     * If not connected to database, load from text file, otherwise load particpant
     * data from the database
     * 
     * @return
     * @throws SQLException
     * @throws FileErrorException
     * @throws IOException
     */
    public boolean getParticipantData() 
    		throws SQLException, FileErrorException, IOException {
    	System.out.println("Getting Participant Data");
    	if(connection==null){
    		ReadFiles file = new ReadFiles();
    		file.setParticipants();
    	} else {
    		PreparedStatement preparedStatement =null;
    		ResultSet rs=null;
    		String query = "select * from ParticipantData";
    		try {
    			preparedStatement = connection.prepareStatement(query);    
    			rs = preparedStatement.executeQuery();
    			while (rs.next()) {
    				if  (!(rs.getString(5).equals("Officer"))){
    					Athlete.getAllAthletes().add(new Athlete(rs.getString(1),
    							rs.getString(2),rs.getInt(3),rs.getString(4),
    							rs.getString(5)));
    				} else { Official.getAllOfficials().add(new Official(rs.getString(1),
    						rs.getString(2),rs.getInt(3),rs.getString(4),rs.getString(5)));
    				}	
    			}   
    			return true;
    		} catch (Exception e) {
    			return false;
    		} finally {
    			preparedStatement.close();
    			rs.close();
    		}
    	}
    	return false;
    }
  
  
    



}
