/**
 * NoGamePresentException class loads the no game present message via the 
 * ErrorMessageTemplate.fxml file 
 */
package application.model;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import application.*;

public class NoGamePresentException extends Exception {
	
	public NoGamePresentException() {

	}

    public NoGamePresentException(String fileName) throws IOException {
    	try {
    		FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(SetUpGame.class.getResource(fileName));
	        AnchorPane errorMessage = (AnchorPane) loader.load();
		    Stage error = new Stage();
		    error.setScene(new Scene(errorMessage));
		    error.setTitle("Error Occured");
		    ErrorMessageTemplateController controller = loader.getController();
	        controller.setNoGamePresentException(this); 
	        controller.setMessage("Sorry you need to set up a new game before "
	        		+ "you can play a game");
		    error.show();
		} catch (IOException e) {
		    e.printStackTrace();
		}
    }


}



