/**
 * NoRefereeException class loads the no referee error message via the 
 * ErrorMessageTemplate.fxml file 
 */

package application.model;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import application.*;

public class NoRefereeException extends Exception {
    
    public NoRefereeException() {
	
    }
    
    public NoRefereeException(String fileName) throws IOException {
    	try {
    		FXMLLoader loader = new FXMLLoader();
            loader.setLocation(SetUpGame.class.getResource(fileName));
            AnchorPane errorMessage = (AnchorPane) loader.load();
            Stage error = new Stage();
            error.setScene(new Scene(errorMessage));
            error.setTitle("Error Occured");
            ErrorMessageTemplateController controller = loader.getController();
            controller.setNoRefereeException(this); 
            controller.setMessage("Oops! You haven't selected a referee for this "
            		+ "event. Please go back and select your referee");
            error.show();
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    }
    
}

   
