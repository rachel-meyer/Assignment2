/**
 * The Official class contains attributes and a constructor to support creation of
 * an Official object.
 * Most of the attributes are common its super class, Participant. 
 * The allOfficials ArrayList is for keeping all of the officials' details.
 * Is also contains methods that are the role of the official in the Ozlympic games:
 * 1/ Summarise the results of all the games including the referee's name
 * 2/ Summarise the current total points of all the athletes competiting in the games.
 */

package application.model;
import java.io.IOException;
import java.util.ArrayList;
import application.*;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class Official extends Participant {
    
    private static ArrayList<Official> allOfficials  = new ArrayList<Official>();
    

    public Official (String id, String name, int age,
	             String state, String type) {
    	super(id, name, age, state, type);	
    }
    
    public Official() {
	
    }
    
    public static ArrayList<Official> getAllOfficials(){
    	return allOfficials;
    }
    
    public ObservableList<Athlete> getAthleteData() {
        return Athlete.getAllAthletes();
    }
    

    /**
     * Loads the DisplayAllGameResults.fxml file.
     * 
     * @param fileName
     * @throws FileErrorException
     */
    public void summariseGames(String fileName) throws FileErrorException {
    	try {
    		FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Official.class.getResource(fileName));
            AnchorPane root = (AnchorPane) loader.load();
            Scene scene = new Scene(root);
            DisplayAllGameResultsController controller = loader.getController();
            controller.setOfficial(this); 
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
            controller.checkForGames("/application/view/ErrorMessageTemplate.fxml");
	    	} catch (IOException e) {
	    		e.printStackTrace();
	    	}
    }
    
    /**
     * Loads the DisplayAthletePoints.fxml file
     * 
     * @param fileName
     * @throws FileErrorException
     */
    public void summarisePoints(String fileName) throws FileErrorException {
    	try {
    		FXMLLoader loader = new FXMLLoader();
    		loader.setLocation(Official.class.getResource(fileName));
    		BorderPane rootLayout = (BorderPane) loader.load();
    		DisplayAthletePointsController controller = loader.getController();
    		rootLayout.setCenter(controller.getAthletePointsTable());
    		controller.setOfficial(this);
    		Stage summarisePoints = new Stage();
    		summarisePoints.setScene(new Scene(rootLayout));
    		summarisePoints.show();
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    }
    
}
