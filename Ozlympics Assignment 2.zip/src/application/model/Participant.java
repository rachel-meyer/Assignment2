/**
 * Participant is an abstract class set up to support creation of 
 * two classes: Athlete and Official. 
 * It contains attributes that are common to both child classes.
 * Is contains constructors to support setting up the Athlete
 * and Official objects. 
 */

package application.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public abstract class Participant {
    
    public Participant() {
    	this(null, null, 0, null, null);
    }

    private final StringProperty id;
    private final StringProperty name;
    private final IntegerProperty age;
    private final StringProperty state;
    private final StringProperty type;
    
    
    
    public Participant (String id, String name, Integer age, String state, String type) {
        this.id = new SimpleStringProperty(id);
        this.name = new SimpleStringProperty(name);
        this.age = new SimpleIntegerProperty(age);
        this.state = new SimpleStringProperty(state);
        this.type = new SimpleStringProperty(type);
    }
     
    
    public String getId() {
        return id.get();
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public StringProperty idProperty() {
        return id;
    }

    public String getName() {
        return name.get();
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public StringProperty nameProperty() {
        return name;
    }

    public int getAge() {
        return age.get();
    }

    public void setAge(int age) {
        this.age.set(age);
    }

    public IntegerProperty ageProperty() {
        return age;
    }

    
    public String getState() {
        return state.get();
    }

    public void setState(String state) {
        this.state.set(state);
    }

    public StringProperty stateProperty() {
        return state;
    }
    public String getType() {
        return type.get();
    }

    public void setType(String type) {
        this.type.set(type);
    }

    public StringProperty typeProperty() {
        return type;
    }
    
}
