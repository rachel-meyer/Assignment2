/**
 * Swimmer is a child class of Athlete used to overwrite the compete method.
 * Swimmer instances will be created when the user sets up a Swimming event. 
 */

package application.model;

import java.util.concurrent.ThreadLocalRandom;

public class Swimmer extends Athlete {
     
    public Swimmer (String id, String name, int age, 
	    	    String state, String type, int points){
    	super(id, name, age, state, type, points);
    }

    
    public Swimmer() {
    }

    /**
     * The compete method overides the compete method in the Athlete superclass
     */
    public Integer compete() {
    	setResult(ThreadLocalRandom.current().nextInt(100, 200 + 1));
    	return getResult();
    }
   
}