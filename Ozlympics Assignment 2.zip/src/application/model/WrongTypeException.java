/**
 * WrongTypeException class loads the wrong athlete type error message via the 
 * ErrorMessageTemplate.fxml file 
 */

package application.model;

import java.io.IOException;
import application.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class WrongTypeException extends Exception {
   
    public WrongTypeException() {

    }
    
    public WrongTypeException(String fileName) throws IOException {
    	try {
    		FXMLLoader loader = new FXMLLoader();
            loader.setLocation(SetUpGame.class.getResource(fileName));
            AnchorPane errorMessage = (AnchorPane) loader.load();
            Stage error = new Stage();
            error.setScene(new Scene(errorMessage));
	    	error.setTitle("Error Occured");
	    	ErrorMessageTemplateController controller = loader.getController();
            controller.setWrongTypeException(this); 
            controller.setMessage("Oops! You have selected some athletes who can't"
            		+ " compete in this event. Please go back and re-select "
            		+ "your competitors");
            error.show();
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    }



}
