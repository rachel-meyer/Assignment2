package application.tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import application.*;
import application.view.*;
import application.model.*;


public class AthleteTest {
    
    Athlete athlete;
    Cyclist cyclist;
    Swimmer swimmer;
    Sprinter sprinter;
    
    @Before
    public void setUp() throws Exception {
	athlete = new Athlete("","",0,"","",5);
	cyclist = new Cyclist();
	swimmer = new Swimmer();
	sprinter = new Sprinter();

	athlete.setGamePoints(5);
	athlete.setResult(200);
    }
    
    @Test
    public void testGetGamePoints() {
	assert(athlete.getGamePoints()==5);
    }

    @Test
    public void testGetResult() {
	assert(athlete.getResult()==200);
    }
    
    @Test
    public void testGetTotalPoints() {
	assert(athlete.getTotalPoints()==5);

    }

    @Test 
    public void testCyclist1() {
    assert(cyclist.compete()>=500);
    }
    
    @Test 
    public void testCyclist2() {
    assert(cyclist.compete()<=800);
    }
    
    @Test 
    public void testCyclist3() {
    assert(cyclist.compete()<=800 && cyclist.compete()>=500);
    }
    
    @Test 
    public void testSwimmer1() {
    assert(swimmer.compete()>=100);
    }
    
    @Test 
    public void testSwimmer2() {
    assert(swimmer.compete()<=200);
    }
    
    @Test 
    public void testSwimmer3() {
    assert(swimmer.compete()<=200 && swimmer.compete()>=100);
    }
    
    
    @Test 
    public void testSprinter1() {
    assert(sprinter.compete()>=10);
    }
    
    @Test 
    public void testSprinter2() {
    assert(sprinter.compete()<=20);
    }
    
    @Test 
    public void testSprinter3() {
    assert(sprinter.compete()<=20 && sprinter.compete()>=10);
    }

}
