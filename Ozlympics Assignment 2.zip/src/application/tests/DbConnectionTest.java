package application.tests;

import static org.junit.Assert.*;
import application.*;
import application.view.*;
import application.model.*;
import org.junit.Before;
import org.junit.Test;


import java.sql.*;

public class DbConnectionTest {
    
    Connection connection1;
    Connection connection2;
    

    @Before
    public void setUp() throws Exception {
	connection1 = DbConnection.Connector("org1.sqlite.JDBC");
	connection2 = DbConnection.Connector("org.sqlite.JDBC");
    }

    @Test
    public void testDbConnection1() throws Exception {
	assert(connection1==null);
    }
    
    @Test
    public void testDbConnection2() throws Exception {
	assert(!(connection2.isClosed()));
    }
    
    @Test
    public void testDbConnection3() throws Exception {
	assert (connection2 !=null);
    }
}
