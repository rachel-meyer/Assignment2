package application.tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import application.*;
import application.model.*;

public class GameTest {
    
    private SetUpGame setup;
    private PlayGame play;
    private Game game;
    private PlayGame testPlay;
    private Game testSetUp;

    @Before
    public void setUp() throws Exception {
	game = new Game();
	game.setPlay(testPlay);
	game.setUpGame(testSetUp);
    }

    @Test
    public void testGetPlay() {
	game.getPlay();
	assert(game.getPlay()==testPlay);
	
    }

}
