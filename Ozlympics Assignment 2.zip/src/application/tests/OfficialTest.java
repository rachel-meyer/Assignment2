package application.tests;

import java.io.IOException;
import org.junit.BeforeClass;
import org.junit.Test;
import application.model.*;

public class OfficialTest {
    
	Official official = new Official();
    Athlete athlete;
    

    @BeforeClass
    public static void setUp() throws Exception {
	Athlete.getAllAthletes().add(new Athlete("id1","",0,"","",0));
	Athlete.getAllAthletes().add(new Athlete("id2","",0,"","",0));
	Athlete.getAllAthletes().add(new Athlete("id3","",0,"","",0));
	Athlete.getAllAthletes().add(new Athlete("id4","",0,"","",0));
	Athlete.getAllAthletes().add(new Athlete("id5","",0,"","",0));
	Official.getAllOfficials().add(new Official("id6","",0,"",""));
	Official.getAllOfficials().add(new Official("id7","",0,"",""));
	Official.getAllOfficials().add(new Official("id8","",0,"",""));
	Official.getAllOfficials().add(new Official("id9","",0,"",""));
	Official.getAllOfficials().add(new Official("id10","",0,"",""));
	
    }

    @Test
    public void testGetAllOfficials1() {
	assert(Official.getAllOfficials().size()==5);
    }
    
    @Test
    public void testGetAllOfficials2() {
	assert(Official.getAllOfficials().get(0).getId()=="id6");
    }
    
    @Test
    public void testGetAllOfficials3() {
	assert(Official.getAllOfficials().get(4).getId()=="id10");
    }


    @Test
    public void testGetAthleteData1() {
	assert(Athlete.getAllAthletes().size()==5);
    }
    
    @Test
    public void testGetAthleteData2() {
	assert(Athlete.getAllAthletes().get(0).getId()=="id1");
    }
    
    @Test
    public void testGetAthleteData3() {
	assert(Athlete.getAllAthletes().get(4).getId()=="id5");
    }

    @Test
    (expected = Exception.class)
    public void testSummariseGames() throws IOException, FileErrorException  {
	official.summariseGames("123");
    }

    @Test
    (expected = Exception.class)
    public void testSummarisePoints() throws IOException, FileErrorException {
	official.summarisePoints("123");
    }

}
