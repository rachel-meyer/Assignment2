package application.tests;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import application.*;
import application.model.*;

public class PlayGameTest {
	
	PlayGame playGame;
	Game game;
	SetUpGame setUp;
    ArrayList<Athlete> competitors;

	@Before
	public void setUp() throws Exception {
		
		game = new Game();
		competitors = new ArrayList<Athlete>();
		setUp = new SetUpGame(game);
		playGame = new PlayGame(game);
		setUp.setEventType("Swimming");
		competitors.add(new Swimmer("id1","",0,"","",0));
		competitors.add(new Swimmer("id2","",0,"","",0));
		competitors.add(new Swimmer("id3","",0,"","",0));
		playGame.compete();
		playGame.sortResults();
		playGame.assignPoints();

	}

	@Test
	public void testCompete1() {
		for (Athlete c: competitors) {
		assert(c.getGamePoints()==0);
		}
	}
	
	@Test
	public void testCompete2() {
		assert((competitors.get(0).getResult()<=800)&&(competitors.get(0).getResult()>=500));
	}
	
	@Test
	public void testCompete3() {
		assert((competitors.get(1).getResult()<=200)&&(competitors.get(0).getResult()>=100));
	}
	
	@Test
	public void testCompeter() {
		assert((competitors.get(2).getResult()<=20)&&(competitors.get(0).getResult()>=10));
	}


	@Test
	public void testSortResults() {
		for(int i=1; i<competitors.size(); i++){
		assert(competitors.get(i-1).getResult() <
				competitors.get(i).getResult());
		    }
	}

	@Test
	public void testAssignPoints1() {
		assert(competitors.get(0).getGamePoints()==5);
	}


}
