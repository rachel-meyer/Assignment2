package application.tests;

import static org.junit.Assert.*;
import java.io.IOException;
import java.util.ArrayList;
import junit.framework.*;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import application.*;
import application.view.*;
import application.model.*;


public class SetUpGameTest {
    
    SetUpGame setUpGame= new SetUpGame();
    Official referee = new Official("ref1"," ",0,"","");
    ArrayList<Athlete> competitors = new ArrayList<Athlete>();

    

    @Before
    public void setUp() throws Exception {

	SetUpGame.resetEventNum(0);
	SetUpGame.setEventNum();
	competitors.add(new Athlete("id1","",0,"","",0));
	competitors.add(new Athlete("id2","",0,"","",0));
	competitors.add(new Athlete("id3","",0,"","",0));
	competitors.add(new Athlete("id4","",0,"","",0));
	competitors.add(new Athlete("id5","",0,"","",0));
	setUpGame.setReferee(referee);
	setUpGame.setEventType("Swimming");
	setUpGame.setEventID();

    }
    
    @After
    public void teardown() throws Exception {
	
    }

    @Test
    public void testGetCompetitors1() {
	assert(competitors.size()==5);
    }
    
    @Test
    public void testGetCompetitors2() {
	assert(competitors.get(0).getId()=="id1");
    }
    
    @Test
    public void testGetCompetitors3() {
	assert(competitors.get(4).getId()=="id5");
    }


    @Test
    public void testEventNum() {
	System.out.println(SetUpGame.getEventNum());
	assert(SetUpGame.getEventNum()==2);
    }


    @Test
    public void testEventID() {
	System.out.println(setUpGame.getEventID());
	assert(setUpGame.getEventID()=="Swimming2");
    }

    @Test
    public void testGetReferee() {
	assert(setUpGame.getReferee().getId()=="ref1");
    }


    @Test
    (expected=Exception.class)
    public void testEventOptions() throws FileErrorException, IOException, IllegalStateException {
	setUpGame.showEventOptions("123");
    }

    @Test
    public void testEventType() {
	assert(setUpGame.getEventType()=="Swimming");
    }


    @Test
    (expected=Exception.class)
    public void testShowCompetitors() throws IOException, FileErrorException, IllegalStateException  {
	setUpGame.showCompetitors("123");
    }

    @Test
    (expected=Exception.class)
    public void testChooseReferee()  throws IOException, FileErrorException, IllegalStateException {
	setUpGame.chooseReferee("123");
    }


}
